﻿namespace QLCafe
{
    partial class frmBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBanHang));
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject1 = new DevExpress.Utils.SerializableAppearanceObject();
            DevExpress.Utils.SerializableAppearanceObject serializableAppearanceObject2 = new DevExpress.Utils.SerializableAppearanceObject();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.btnXoa = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.btnThemKhachHang = new DevExpress.XtraEditors.SimpleButton();
            this.cmbTenKhachHang = new DevExpress.XtraEditors.GridLookUpEdit();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonXoaBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonChuyenBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGopBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonDatBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonTachBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonChonMon = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonTinhGio = new DevExpress.XtraBars.BarButtonItem();
            this.gridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn15 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnInPhaChe = new DevExpress.XtraEditors.SimpleButton();
            this.btnInTam = new DevExpress.XtraEditors.SimpleButton();
            this.cmbHinhThucGiamGia = new DevExpress.XtraEditors.ComboBoxEdit();
            this.btnThanhToan = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.btnTachHoaDon = new DevExpress.XtraEditors.SimpleButton();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.txtGiamGiaHoaDon = new DevExpress.XtraEditors.SpinEdit();
            this.txtDiemTichLuy = new DevExpress.XtraEditors.SpinEdit();
            this.txtTienThoi = new DevExpress.XtraEditors.SpinEdit();
            this.txtKhachThanhToan = new DevExpress.XtraEditors.SpinEdit();
            this.txtKhachCanTra = new DevExpress.XtraEditors.SpinEdit();
            this.txtGiamGiaDiem = new DevExpress.XtraEditors.SpinEdit();
            this.txtTongGiamGia = new DevExpress.XtraEditors.SpinEdit();
            this.txtGiamGia = new DevExpress.XtraEditors.SpinEdit();
            this.txtTongTien = new DevExpress.XtraEditors.SpinEdit();
            this.gridControlCTHD = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit2 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemTextEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemTextEdit();
            this.btnXoaHangHoa = new DevExpress.XtraGrid.Columns.GridColumn();
            this.btnXoaMonAn = new DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.lblNgay = new DevExpress.XtraEditors.LabelControl();
            this.lblTenBan = new DevExpress.XtraEditors.LabelControl();
            this.xtraTabControlDanhSach = new DevExpress.XtraTab.XtraTabControl();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.btnMayIn = new DevExpress.XtraEditors.SimpleButton();
            this.txtGioVao = new DevExpress.XtraEditors.LabelControl();
            this.lblTime = new DevExpress.XtraEditors.LabelControl();
            this.txtTenDangNhap = new DevExpress.XtraEditors.LabelControl();
            this.txtTyLyPhucVu = new DevExpress.XtraEditors.LabelControl();
            this.btnCoNguoi = new DevExpress.XtraEditors.SimpleButton();
            this.btnKetCa = new DevExpress.XtraEditors.SimpleButton();
            this.btnDatTruoc = new DevExpress.XtraEditors.SimpleButton();
            this.btnTrong = new DevExpress.XtraEditors.SimpleButton();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.lblDiaChi = new DevExpress.XtraEditors.LabelControl();
            this.lblDienThoai = new DevExpress.XtraEditors.LabelControl();
            this.lblTenCongTy = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.menuBan = new DevExpress.XtraBars.PopupMenu(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoa)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTenKhachHang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbHinhThucGiamGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGiaHoaDon.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemTichLuy.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienThoi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachThanhToan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachCanTra.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGiaDiem.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongGiamGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongTien.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCTHD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoaMonAn)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlDanhSach)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            this.panelControl3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBan)).BeginInit();
            this.SuspendLayout();
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit1.DisplayFormat.FormatString = "N0";
            this.repositoryItemSpinEdit1.EditFormat.FormatString = "N0";
            this.repositoryItemSpinEdit1.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.repositoryItemSpinEdit1.MaxValue = new decimal(new int[] {
            900,
            0,
            0,
            0});
            this.repositoryItemSpinEdit1.MinValue = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // btnXoa
            // 
            this.btnXoa.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("btnXoa.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject1, "", null, null, true)});
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.panelControl2);
            this.panelControl1.Controls.Add(this.gridControlCTHD);
            this.panelControl1.Controls.Add(this.lblNgay);
            this.panelControl1.Controls.Add(this.lblTenBan);
            this.panelControl1.Controls.Add(this.xtraTabControlDanhSach);
            this.panelControl1.Controls.Add(this.groupControl4);
            this.panelControl1.Controls.Add(this.panelControl3);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1311, 698);
            this.panelControl1.TabIndex = 0;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.btnThemKhachHang);
            this.panelControl2.Controls.Add(this.cmbTenKhachHang);
            this.panelControl2.Controls.Add(this.btnInPhaChe);
            this.panelControl2.Controls.Add(this.btnInTam);
            this.panelControl2.Controls.Add(this.cmbHinhThucGiamGia);
            this.panelControl2.Controls.Add(this.btnThanhToan);
            this.panelControl2.Controls.Add(this.labelControl4);
            this.panelControl2.Controls.Add(this.labelControl12);
            this.panelControl2.Controls.Add(this.btnTachHoaDon);
            this.panelControl2.Controls.Add(this.labelControl1);
            this.panelControl2.Controls.Add(this.labelControl11);
            this.panelControl2.Controls.Add(this.labelControl8);
            this.panelControl2.Controls.Add(this.labelControl6);
            this.panelControl2.Controls.Add(this.labelControl7);
            this.panelControl2.Controls.Add(this.labelControl5);
            this.panelControl2.Controls.Add(this.labelControl3);
            this.panelControl2.Controls.Add(this.labelControl2);
            this.panelControl2.Controls.Add(this.txtGiamGiaHoaDon);
            this.panelControl2.Controls.Add(this.txtDiemTichLuy);
            this.panelControl2.Controls.Add(this.txtTienThoi);
            this.panelControl2.Controls.Add(this.txtKhachThanhToan);
            this.panelControl2.Controls.Add(this.txtKhachCanTra);
            this.panelControl2.Controls.Add(this.txtGiamGiaDiem);
            this.panelControl2.Controls.Add(this.txtTongGiamGia);
            this.panelControl2.Controls.Add(this.txtGiamGia);
            this.panelControl2.Controls.Add(this.txtTongTien);
            this.panelControl2.Location = new System.Drawing.Point(572, 416);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(727, 256);
            this.panelControl2.TabIndex = 13;
            // 
            // btnThemKhachHang
            // 
            this.btnThemKhachHang.Image = ((System.Drawing.Image)(resources.GetObject("btnThemKhachHang.Image")));
            this.btnThemKhachHang.Location = new System.Drawing.Point(346, 16);
            this.btnThemKhachHang.Name = "btnThemKhachHang";
            this.btnThemKhachHang.Size = new System.Drawing.Size(25, 27);
            this.btnThemKhachHang.TabIndex = 26;
            this.btnThemKhachHang.Click += new System.EventHandler(this.btnThemKhachHang_Click);
            // 
            // cmbTenKhachHang
            // 
            this.cmbTenKhachHang.EditValue = "1";
            this.cmbTenKhachHang.Location = new System.Drawing.Point(182, 17);
            this.cmbTenKhachHang.MenuManager = this.barManager1;
            this.cmbTenKhachHang.Name = "cmbTenKhachHang";
            this.cmbTenKhachHang.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTenKhachHang.Properties.Appearance.Options.UseFont = true;
            this.cmbTenKhachHang.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbTenKhachHang.Properties.NullText = "";
            this.cmbTenKhachHang.Properties.PopupFormSize = new System.Drawing.Size(700, 400);
            this.cmbTenKhachHang.Properties.View = this.gridLookUpEdit1View;
            this.cmbTenKhachHang.Size = new System.Drawing.Size(161, 26);
            this.cmbTenKhachHang.TabIndex = 25;
            this.cmbTenKhachHang.EditValueChanged += new System.EventHandler(this.cmbTenKhachHang_EditValueChanged);
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem1,
            this.barButtonXoaBan,
            this.barButtonChuyenBan,
            this.barButtonGopBan,
            this.barButtonItem5,
            this.barButtonDatBan,
            this.barButtonTachBan,
            this.barButtonChonMon,
            this.barButtonTinhGio});
            this.barManager1.MaxItemId = 9;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1311, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 698);
            this.barDockControlBottom.Size = new System.Drawing.Size(1311, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 698);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1311, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 698);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Đặt Bàn";
            this.barButtonItem1.Id = 0;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonXoaBan
            // 
            this.barButtonXoaBan.Caption = "Xóa Bàn";
            this.barButtonXoaBan.Id = 1;
            this.barButtonXoaBan.ImageUri.Uri = "Cancel";
            this.barButtonXoaBan.Name = "barButtonXoaBan";
            this.barButtonXoaBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonXoaBan_ItemClick);
            // 
            // barButtonChuyenBan
            // 
            this.barButtonChuyenBan.Caption = "Chuyển Bàn";
            this.barButtonChuyenBan.Id = 2;
            this.barButtonChuyenBan.ImageUri.Uri = "Replace";
            this.barButtonChuyenBan.Name = "barButtonChuyenBan";
            this.barButtonChuyenBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonChuyenBan_ItemClick);
            // 
            // barButtonGopBan
            // 
            this.barButtonGopBan.Caption = "Gộp Bàn";
            this.barButtonGopBan.Id = 3;
            this.barButtonGopBan.ImageUri.Uri = "Refresh";
            this.barButtonGopBan.Name = "barButtonGopBan";
            this.barButtonGopBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonGopBan_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Id = 4;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonDatBan
            // 
            this.barButtonDatBan.Caption = "Đặt Bàn";
            this.barButtonDatBan.Id = 5;
            this.barButtonDatBan.ImageUri.Uri = "Apply";
            this.barButtonDatBan.Name = "barButtonDatBan";
            this.barButtonDatBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDatBan_ItemClick);
            // 
            // barButtonTachBan
            // 
            this.barButtonTachBan.Caption = "Tách Bàn";
            this.barButtonTachBan.Id = 6;
            this.barButtonTachBan.ImageUri.Uri = "Cut";
            this.barButtonTachBan.Name = "barButtonTachBan";
            this.barButtonTachBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonTachBan_ItemClick);
            // 
            // barButtonChonMon
            // 
            this.barButtonChonMon.Caption = "Gọi Món";
            this.barButtonChonMon.Id = 7;
            this.barButtonChonMon.ImageUri.Uri = "Edit";
            this.barButtonChonMon.Name = "barButtonChonMon";
            this.barButtonChonMon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonChonMon_ItemClick);
            // 
            // barButtonTinhGio
            // 
            this.barButtonTinhGio.Caption = "Tính GIờ";
            this.barButtonTinhGio.Id = 8;
            this.barButtonTinhGio.ImageUri.Uri = "NavigationBar";
            this.barButtonTinhGio.Name = "barButtonTinhGio";
            this.barButtonTinhGio.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonTinhGio_ItemClick);
            // 
            // gridLookUpEdit1View
            // 
            this.gridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14,
            this.gridColumn15});
            this.gridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridLookUpEdit1View.Name = "gridLookUpEdit1View";
            this.gridLookUpEdit1View.OptionsDetail.DetailMode = DevExpress.XtraGrid.Views.Grid.DetailMode.Default;
            this.gridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridLookUpEdit1View.OptionsView.ShowAutoFilterRow = true;
            this.gridLookUpEdit1View.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.gridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "Mã Khách Hàng";
            this.gridColumn11.FieldName = "MaKhachHang";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 0;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "Tên Khách Hàng";
            this.gridColumn12.FieldName = "TenKhachHang";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 1;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "Điện Thoại";
            this.gridColumn13.FieldName = "DienThoai";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.OptionsFilter.AutoFilterCondition = DevExpress.XtraGrid.Columns.AutoFilterCondition.Contains;
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 2;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "CMND";
            this.gridColumn14.FieldName = "CMND";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 3;
            // 
            // gridColumn15
            // 
            this.gridColumn15.Caption = "Điểm Tích Lũy";
            this.gridColumn15.FieldName = "DiemTichLuy";
            this.gridColumn15.Name = "gridColumn15";
            this.gridColumn15.Visible = true;
            this.gridColumn15.VisibleIndex = 4;
            // 
            // btnInPhaChe
            // 
            this.btnInPhaChe.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInPhaChe.Appearance.Options.UseFont = true;
            this.btnInPhaChe.Image = ((System.Drawing.Image)(resources.GetObject("btnInPhaChe.Image")));
            this.btnInPhaChe.Location = new System.Drawing.Point(38, 215);
            this.btnInPhaChe.Name = "btnInPhaChe";
            this.btnInPhaChe.Size = new System.Drawing.Size(163, 36);
            this.btnInPhaChe.TabIndex = 3;
            this.btnInPhaChe.Text = "In Pha Chế (0)";
            this.btnInPhaChe.Click += new System.EventHandler(this.btnInPhaChe_Click);
            // 
            // btnInTam
            // 
            this.btnInTam.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInTam.Appearance.Options.UseFont = true;
            this.btnInTam.Image = ((System.Drawing.Image)(resources.GetObject("btnInTam.Image")));
            this.btnInTam.Location = new System.Drawing.Point(221, 215);
            this.btnInTam.Name = "btnInTam";
            this.btnInTam.Size = new System.Drawing.Size(158, 36);
            this.btnInTam.TabIndex = 3;
            this.btnInTam.Text = "In Tạm (0)";
            this.btnInTam.Click += new System.EventHandler(this.btnInTam_Click);
            // 
            // cmbHinhThucGiamGia
            // 
            this.cmbHinhThucGiamGia.EditValue = "$";
            this.cmbHinhThucGiamGia.Location = new System.Drawing.Point(547, 88);
            this.cmbHinhThucGiamGia.MenuManager = this.barManager1;
            this.cmbHinhThucGiamGia.Name = "cmbHinhThucGiamGia";
            this.cmbHinhThucGiamGia.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbHinhThucGiamGia.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.cmbHinhThucGiamGia.Properties.Appearance.Options.UseFont = true;
            this.cmbHinhThucGiamGia.Properties.Appearance.Options.UseForeColor = true;
            this.cmbHinhThucGiamGia.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbHinhThucGiamGia.Properties.Items.AddRange(new object[] {
            "$",
            "%"});
            this.cmbHinhThucGiamGia.Properties.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.DisableTextEditor;
            this.cmbHinhThucGiamGia.Size = new System.Drawing.Size(47, 30);
            this.cmbHinhThucGiamGia.TabIndex = 24;
            this.cmbHinhThucGiamGia.SelectedIndexChanged += new System.EventHandler(this.cmbHinhThucGiamGia_SelectedIndexChanged);
            // 
            // btnThanhToan
            // 
            this.btnThanhToan.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThanhToan.Appearance.Options.UseFont = true;
            this.btnThanhToan.Image = ((System.Drawing.Image)(resources.GetObject("btnThanhToan.Image")));
            this.btnThanhToan.Location = new System.Drawing.Point(546, 215);
            this.btnThanhToan.Name = "btnThanhToan";
            this.btnThanhToan.Size = new System.Drawing.Size(135, 36);
            this.btnThanhToan.TabIndex = 3;
            this.btnThanhToan.Text = "Thanh Toán";
            this.btnThanhToan.Click += new System.EventHandler(this.btnThanhToan_Click);
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Location = new System.Drawing.Point(371, 20);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl4.Size = new System.Drawing.Size(120, 18);
            this.labelControl4.TabIndex = 4;
            this.labelControl4.Text = "ĐIỂM QUI ĐỔI";
            // 
            // labelControl12
            // 
            this.labelControl12.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl12.Location = new System.Drawing.Point(6, 177);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl12.Size = new System.Drawing.Size(90, 18);
            this.labelControl12.TabIndex = 4;
            this.labelControl12.Text = "TIỀN THỒI";
            // 
            // btnTachHoaDon
            // 
            this.btnTachHoaDon.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTachHoaDon.Appearance.Options.UseFont = true;
            this.btnTachHoaDon.Image = ((System.Drawing.Image)(resources.GetObject("btnTachHoaDon.Image")));
            this.btnTachHoaDon.Location = new System.Drawing.Point(399, 215);
            this.btnTachHoaDon.Name = "btnTachHoaDon";
            this.btnTachHoaDon.Size = new System.Drawing.Size(125, 36);
            this.btnTachHoaDon.TabIndex = 3;
            this.btnTachHoaDon.Text = "Tách Bill";
            this.btnTachHoaDon.Click += new System.EventHandler(this.btnTachHoaDon_Click);
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Location = new System.Drawing.Point(5, 20);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl1.Size = new System.Drawing.Size(144, 18);
            this.labelControl1.TabIndex = 4;
            this.labelControl1.Text = "TÊN KHÁCH HÀNG";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(5, 139);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl11.Size = new System.Drawing.Size(166, 18);
            this.labelControl11.TabIndex = 4;
            this.labelControl11.Text = "KHÁCH THANH TOÁN";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Location = new System.Drawing.Point(5, 100);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl8.Size = new System.Drawing.Size(132, 18);
            this.labelControl8.TabIndex = 4;
            this.labelControl8.Text = "KHÁCH CẦN TRẢ";
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl6.Location = new System.Drawing.Point(370, 58);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl6.Size = new System.Drawing.Size(128, 18);
            this.labelControl6.TabIndex = 4;
            this.labelControl6.Text = "GIẢM GIÁ ĐIỂM";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(370, 177);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl7.Size = new System.Drawing.Size(131, 18);
            this.labelControl7.TabIndex = 4;
            this.labelControl7.Text = "TỔNG GIẢM GIÁ";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Location = new System.Drawing.Point(370, 134);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl5.Size = new System.Drawing.Size(161, 18);
            this.labelControl5.TabIndex = 4;
            this.labelControl5.Text = "GIẢM GIÁ HÓA ĐƠN";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Location = new System.Drawing.Point(370, 96);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl3.Size = new System.Drawing.Size(174, 18);
            this.labelControl3.TabIndex = 4;
            this.labelControl3.Text = "HÌNH THỨC GIẢM GIÁ";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Location = new System.Drawing.Point(5, 61);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl2.Size = new System.Drawing.Size(114, 18);
            this.labelControl2.TabIndex = 4;
            this.labelControl2.Text = "TIỀN MÓN ĂN";
            // 
            // txtGiamGiaHoaDon
            // 
            this.txtGiamGiaHoaDon.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGiamGiaHoaDon.Location = new System.Drawing.Point(591, 88);
            this.txtGiamGiaHoaDon.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtGiamGiaHoaDon.Name = "txtGiamGiaHoaDon";
            this.txtGiamGiaHoaDon.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGiamGiaHoaDon.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiamGiaHoaDon.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtGiamGiaHoaDon.Properties.Appearance.Options.UseBackColor = true;
            this.txtGiamGiaHoaDon.Properties.Appearance.Options.UseFont = true;
            this.txtGiamGiaHoaDon.Properties.Appearance.Options.UseForeColor = true;
            this.txtGiamGiaHoaDon.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtGiamGiaHoaDon.Properties.DisplayFormat.FormatString = "N0";
            this.txtGiamGiaHoaDon.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtGiamGiaHoaDon.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtGiamGiaHoaDon.Size = new System.Drawing.Size(131, 30);
            this.txtGiamGiaHoaDon.TabIndex = 23;
            this.txtGiamGiaHoaDon.EditValueChanged += new System.EventHandler(this.txtGiamGiaHoaDon_EditValueChanged);
            // 
            // txtDiemTichLuy
            // 
            this.txtDiemTichLuy.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtDiemTichLuy.Location = new System.Drawing.Point(547, 13);
            this.txtDiemTichLuy.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtDiemTichLuy.Name = "txtDiemTichLuy";
            this.txtDiemTichLuy.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDiemTichLuy.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiemTichLuy.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtDiemTichLuy.Properties.Appearance.Options.UseBackColor = true;
            this.txtDiemTichLuy.Properties.Appearance.Options.UseFont = true;
            this.txtDiemTichLuy.Properties.Appearance.Options.UseForeColor = true;
            this.txtDiemTichLuy.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtDiemTichLuy.Properties.DisplayFormat.FormatString = "N0";
            this.txtDiemTichLuy.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtDiemTichLuy.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtDiemTichLuy.Size = new System.Drawing.Size(175, 30);
            this.txtDiemTichLuy.TabIndex = 23;
            this.txtDiemTichLuy.EditValueChanged += new System.EventHandler(this.txtDiemTichLuy_EditValueChanged);
            // 
            // txtTienThoi
            // 
            this.txtTienThoi.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTienThoi.Enabled = false;
            this.txtTienThoi.Location = new System.Drawing.Point(182, 170);
            this.txtTienThoi.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtTienThoi.Name = "txtTienThoi";
            this.txtTienThoi.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTienThoi.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTienThoi.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtTienThoi.Properties.Appearance.Options.UseBackColor = true;
            this.txtTienThoi.Properties.Appearance.Options.UseFont = true;
            this.txtTienThoi.Properties.Appearance.Options.UseForeColor = true;
            this.txtTienThoi.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtTienThoi.Properties.DisplayFormat.FormatString = "N0";
            this.txtTienThoi.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtTienThoi.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtTienThoi.Size = new System.Drawing.Size(175, 30);
            this.txtTienThoi.TabIndex = 23;
            // 
            // txtKhachThanhToan
            // 
            this.txtKhachThanhToan.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtKhachThanhToan.Location = new System.Drawing.Point(182, 132);
            this.txtKhachThanhToan.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtKhachThanhToan.Name = "txtKhachThanhToan";
            this.txtKhachThanhToan.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtKhachThanhToan.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhachThanhToan.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtKhachThanhToan.Properties.Appearance.Options.UseBackColor = true;
            this.txtKhachThanhToan.Properties.Appearance.Options.UseFont = true;
            this.txtKhachThanhToan.Properties.Appearance.Options.UseForeColor = true;
            this.txtKhachThanhToan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtKhachThanhToan.Properties.DisplayFormat.FormatString = "N0";
            this.txtKhachThanhToan.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtKhachThanhToan.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtKhachThanhToan.Size = new System.Drawing.Size(175, 30);
            this.txtKhachThanhToan.TabIndex = 23;
            this.txtKhachThanhToan.EditValueChanged += new System.EventHandler(this.txtKhachThanhToan_EditValueChanged);
            // 
            // txtKhachCanTra
            // 
            this.txtKhachCanTra.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtKhachCanTra.Location = new System.Drawing.Point(182, 93);
            this.txtKhachCanTra.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtKhachCanTra.Name = "txtKhachCanTra";
            this.txtKhachCanTra.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtKhachCanTra.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhachCanTra.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtKhachCanTra.Properties.Appearance.Options.UseBackColor = true;
            this.txtKhachCanTra.Properties.Appearance.Options.UseFont = true;
            this.txtKhachCanTra.Properties.Appearance.Options.UseForeColor = true;
            this.txtKhachCanTra.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtKhachCanTra.Properties.DisplayFormat.FormatString = "N0";
            this.txtKhachCanTra.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtKhachCanTra.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtKhachCanTra.Properties.ReadOnly = true;
            this.txtKhachCanTra.Size = new System.Drawing.Size(175, 30);
            this.txtKhachCanTra.TabIndex = 23;
            // 
            // txtGiamGiaDiem
            // 
            this.txtGiamGiaDiem.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGiamGiaDiem.Enabled = false;
            this.txtGiamGiaDiem.Location = new System.Drawing.Point(547, 51);
            this.txtGiamGiaDiem.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtGiamGiaDiem.Name = "txtGiamGiaDiem";
            this.txtGiamGiaDiem.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGiamGiaDiem.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiamGiaDiem.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtGiamGiaDiem.Properties.Appearance.Options.UseBackColor = true;
            this.txtGiamGiaDiem.Properties.Appearance.Options.UseFont = true;
            this.txtGiamGiaDiem.Properties.Appearance.Options.UseForeColor = true;
            this.txtGiamGiaDiem.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtGiamGiaDiem.Properties.DisplayFormat.FormatString = "N0";
            this.txtGiamGiaDiem.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtGiamGiaDiem.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtGiamGiaDiem.Size = new System.Drawing.Size(175, 30);
            this.txtGiamGiaDiem.TabIndex = 23;
            // 
            // txtTongGiamGia
            // 
            this.txtTongGiamGia.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTongGiamGia.Enabled = false;
            this.txtTongGiamGia.Location = new System.Drawing.Point(547, 170);
            this.txtTongGiamGia.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtTongGiamGia.Name = "txtTongGiamGia";
            this.txtTongGiamGia.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTongGiamGia.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongGiamGia.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtTongGiamGia.Properties.Appearance.Options.UseBackColor = true;
            this.txtTongGiamGia.Properties.Appearance.Options.UseFont = true;
            this.txtTongGiamGia.Properties.Appearance.Options.UseForeColor = true;
            this.txtTongGiamGia.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtTongGiamGia.Properties.DisplayFormat.FormatString = "N0";
            this.txtTongGiamGia.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtTongGiamGia.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtTongGiamGia.Size = new System.Drawing.Size(175, 30);
            this.txtTongGiamGia.TabIndex = 23;
            this.txtTongGiamGia.EditValueChanged += new System.EventHandler(this.txtGiamGia_EditValueChanged);
            // 
            // txtGiamGia
            // 
            this.txtGiamGia.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGiamGia.Enabled = false;
            this.txtGiamGia.Location = new System.Drawing.Point(547, 127);
            this.txtGiamGia.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtGiamGia.Name = "txtGiamGia";
            this.txtGiamGia.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGiamGia.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiamGia.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtGiamGia.Properties.Appearance.Options.UseBackColor = true;
            this.txtGiamGia.Properties.Appearance.Options.UseFont = true;
            this.txtGiamGia.Properties.Appearance.Options.UseForeColor = true;
            this.txtGiamGia.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtGiamGia.Properties.DisplayFormat.FormatString = "N0";
            this.txtGiamGia.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtGiamGia.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtGiamGia.Size = new System.Drawing.Size(175, 30);
            this.txtGiamGia.TabIndex = 23;
            // 
            // txtTongTien
            // 
            this.txtTongTien.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTongTien.Enabled = false;
            this.txtTongTien.Location = new System.Drawing.Point(182, 54);
            this.txtTongTien.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTongTien.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtTongTien.Properties.Appearance.Options.UseBackColor = true;
            this.txtTongTien.Properties.Appearance.Options.UseFont = true;
            this.txtTongTien.Properties.Appearance.Options.UseForeColor = true;
            this.txtTongTien.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtTongTien.Properties.DisplayFormat.FormatString = "N0";
            this.txtTongTien.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtTongTien.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtTongTien.Size = new System.Drawing.Size(175, 30);
            this.txtTongTien.TabIndex = 23;
            // 
            // gridControlCTHD
            // 
            this.gridControlCTHD.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridControlCTHD.Location = new System.Drawing.Point(572, 111);
            this.gridControlCTHD.MainView = this.gridView1;
            this.gridControlCTHD.MenuManager = this.barManager1;
            this.gridControlCTHD.Name = "gridControlCTHD";
            this.gridControlCTHD.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.btnXoaMonAn,
            this.repositoryItemSpinEdit2,
            this.repositoryItemTextEdit1});
            this.gridControlCTHD.Size = new System.Drawing.Size(727, 308);
            this.gridControlCTHD.TabIndex = 12;
            this.gridControlCTHD.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            this.gridControlCTHD.ProcessGridKey += new System.Windows.Forms.KeyEventHandler(this.gridControlCTHD_ProcessGridKey);
            // 
            // gridView1
            // 
            this.gridView1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.Style3D;
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn6,
            this.gridColumn5,
            this.gridColumn9,
            this.gridColumn10,
            this.btnXoaHangHoa,
            this.gridColumn7,
            this.gridColumn8});
            this.gridView1.GridControl = this.gridControlCTHD;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsDetail.DetailMode = DevExpress.XtraGrid.Views.Grid.DetailMode.Default;
            this.gridView1.OptionsView.ShowFooter = true;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            this.gridView1.OptionsView.ShowIndicator = false;
            this.gridView1.OptionsView.ShowVerticalLines = DevExpress.Utils.DefaultBoolean.False;
            this.gridView1.OptionsView.ShowViewCaption = true;
            this.gridView1.ViewCaption = "DANH SÁCH MÓN ĂN";
            this.gridView1.RowStyle += new DevExpress.XtraGrid.Views.Grid.RowStyleEventHandler(this.gridView1_RowStyle);
            this.gridView1.InvalidRowException += new DevExpress.XtraGrid.Views.Base.InvalidRowExceptionEventHandler(this.gridView1_InvalidRowException);
            this.gridView1.ValidateRow += new DevExpress.XtraGrid.Views.Base.ValidateRowEventHandler(this.gridView1_ValidateRow);
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Mã Món";
            this.gridColumn1.FieldName = "MaHangHoa";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 61;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Tên Món";
            this.gridColumn2.FieldName = "TenHangHoa";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Count, "TenHangHoa", "Tổng mặt hàng: {0}")});
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 194;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "ĐVT";
            this.gridColumn3.FieldName = "DonViTinh";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 51;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "SL";
            this.gridColumn4.ColumnEdit = this.repositoryItemSpinEdit1;
            this.gridColumn4.DisplayFormat.FormatString = "N0";
            this.gridColumn4.FieldName = "SoLuong";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow;
            this.gridColumn4.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "SoLuong", "{0:N0}")});
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 4;
            this.gridColumn4.Width = 37;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "Trọng Lượng";
            this.gridColumn6.ColumnEdit = this.repositoryItemSpinEdit2;
            this.gridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Numeric;
            this.gridColumn6.FieldName = "TrongLuong";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 3;
            this.gridColumn6.Width = 80;
            // 
            // repositoryItemSpinEdit2
            // 
            this.repositoryItemSpinEdit2.AutoHeight = false;
            this.repositoryItemSpinEdit2.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit2.Name = "repositoryItemSpinEdit2";
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Đơn Giá";
            this.gridColumn5.DisplayFormat.FormatString = "N0";
            this.gridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn5.FieldName = "DonGia";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 5;
            this.gridColumn5.Width = 61;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Thành Tiền";
            this.gridColumn9.DisplayFormat.FormatString = "N0";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn9.FieldName = "ThanhTien";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Summary.AddRange(new DevExpress.XtraGrid.GridSummaryItem[] {
            new DevExpress.XtraGrid.GridColumnSummaryItem(DevExpress.Data.SummaryItemType.Sum, "ThanhTien", "{0:N0}")});
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 6;
            this.gridColumn9.Width = 79;
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "Ghi Chú";
            this.gridColumn10.ColumnEdit = this.repositoryItemTextEdit1;
            this.gridColumn10.FieldName = "GhiChu";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 7;
            this.gridColumn10.Width = 113;
            // 
            // repositoryItemTextEdit1
            // 
            this.repositoryItemTextEdit1.AutoHeight = false;
            this.repositoryItemTextEdit1.Name = "repositoryItemTextEdit1";
            // 
            // btnXoaHangHoa
            // 
            this.btnXoaHangHoa.Caption = "Xóa";
            this.btnXoaHangHoa.ColumnEdit = this.btnXoaMonAn;
            this.btnXoaHangHoa.Name = "btnXoaHangHoa";
            this.btnXoaHangHoa.Visible = true;
            this.btnXoaHangHoa.VisibleIndex = 8;
            this.btnXoaHangHoa.Width = 49;
            // 
            // btnXoaMonAn
            // 
            this.btnXoaMonAn.AutoHeight = false;
            this.btnXoaMonAn.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Glyph, "", -1, true, true, false, DevExpress.XtraEditors.ImageLocation.MiddleCenter, ((System.Drawing.Image)(resources.GetObject("btnXoaMonAn.Buttons"))), new DevExpress.Utils.KeyShortcut(System.Windows.Forms.Keys.None), serializableAppearanceObject2, "", null, null, true)});
            this.btnXoaMonAn.Name = "btnXoaMonAn";
            this.btnXoaMonAn.TextEditStyle = DevExpress.XtraEditors.Controls.TextEditStyles.HideTextEditor;
            this.btnXoaMonAn.Click += new System.EventHandler(this.btnXoaMonAn_Click);
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "ID";
            this.gridColumn7.FieldName = "ID";
            this.gridColumn7.Name = "gridColumn7";
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "Trạng Thái";
            this.gridColumn8.FieldName = "TrangThai";
            this.gridColumn8.Name = "gridColumn8";
            // 
            // lblNgay
            // 
            this.lblNgay.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNgay.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblNgay.Location = new System.Drawing.Point(348, 673);
            this.lblNgay.Name = "lblNgay";
            this.lblNgay.Size = new System.Drawing.Size(81, 18);
            this.lblNgay.TabIndex = 11;
            this.lblNgay.Text = "labelControl6";
            // 
            // lblTenBan
            // 
            this.lblTenBan.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenBan.Location = new System.Drawing.Point(18, 673);
            this.lblTenBan.Name = "lblTenBan";
            this.lblTenBan.Size = new System.Drawing.Size(65, 18);
            this.lblTenBan.TabIndex = 10;
            this.lblTenBan.Text = "Tên bàn: ";
            // 
            // xtraTabControlDanhSach
            // 
            this.xtraTabControlDanhSach.Location = new System.Drawing.Point(5, 111);
            this.xtraTabControlDanhSach.Name = "xtraTabControlDanhSach";
            this.xtraTabControlDanhSach.Size = new System.Drawing.Size(560, 559);
            this.xtraTabControlDanhSach.TabIndex = 9;
            this.xtraTabControlDanhSach.Click += new System.EventHandler(this.xtraTabControlDanhSach_Click);
            // 
            // groupControl4
            // 
            this.groupControl4.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl4.AppearanceCaption.Options.UseFont = true;
            this.groupControl4.Controls.Add(this.btnMayIn);
            this.groupControl4.Controls.Add(this.txtGioVao);
            this.groupControl4.Controls.Add(this.lblTime);
            this.groupControl4.Controls.Add(this.txtTenDangNhap);
            this.groupControl4.Controls.Add(this.txtTyLyPhucVu);
            this.groupControl4.Controls.Add(this.btnCoNguoi);
            this.groupControl4.Controls.Add(this.btnKetCa);
            this.groupControl4.Controls.Add(this.btnDatTruoc);
            this.groupControl4.Controls.Add(this.btnTrong);
            this.groupControl4.Location = new System.Drawing.Point(5, 4);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(560, 105);
            this.groupControl4.TabIndex = 8;
            this.groupControl4.Text = "Trạng Thái";
            // 
            // btnMayIn
            // 
            this.btnMayIn.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnMayIn.Appearance.Options.UseFont = true;
            this.btnMayIn.Image = ((System.Drawing.Image)(resources.GetObject("btnMayIn.Image")));
            this.btnMayIn.Location = new System.Drawing.Point(416, 27);
            this.btnMayIn.Name = "btnMayIn";
            this.btnMayIn.Size = new System.Drawing.Size(100, 34);
            this.btnMayIn.TabIndex = 20;
            this.btnMayIn.Text = "Máy In";
            this.btnMayIn.Click += new System.EventHandler(this.btnMayIn_Click);
            // 
            // txtGioVao
            // 
            this.txtGioVao.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGioVao.Location = new System.Drawing.Point(140, 78);
            this.txtGioVao.Name = "txtGioVao";
            this.txtGioVao.Size = new System.Drawing.Size(0, 18);
            this.txtGioVao.TabIndex = 6;
            // 
            // lblTime
            // 
            this.lblTime.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblTime.Location = new System.Drawing.Point(384, 78);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(81, 18);
            this.lblTime.TabIndex = 5;
            this.lblTime.Text = "labelControl6";
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDangNhap.Location = new System.Drawing.Point(152, 78);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.Size = new System.Drawing.Size(81, 18);
            this.txtTenDangNhap.TabIndex = 4;
            this.txtTenDangNhap.Text = "labelControl6";
            // 
            // txtTyLyPhucVu
            // 
            this.txtTyLyPhucVu.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTyLyPhucVu.Location = new System.Drawing.Point(10, 78);
            this.txtTyLyPhucVu.Name = "txtTyLyPhucVu";
            this.txtTyLyPhucVu.Size = new System.Drawing.Size(81, 18);
            this.txtTyLyPhucVu.TabIndex = 1;
            this.txtTyLyPhucVu.Text = "labelControl5";
            // 
            // btnCoNguoi
            // 
            this.btnCoNguoi.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoNguoi.Appearance.Options.UseFont = true;
            this.btnCoNguoi.Location = new System.Drawing.Point(204, 26);
            this.btnCoNguoi.Name = "btnCoNguoi";
            this.btnCoNguoi.Size = new System.Drawing.Size(98, 36);
            this.btnCoNguoi.TabIndex = 0;
            // 
            // btnKetCa
            // 
            this.btnKetCa.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKetCa.Appearance.Options.UseFont = true;
            this.btnKetCa.Image = ((System.Drawing.Image)(resources.GetObject("btnKetCa.Image")));
            this.btnKetCa.Location = new System.Drawing.Point(308, 25);
            this.btnKetCa.Name = "btnKetCa";
            this.btnKetCa.Size = new System.Drawing.Size(102, 36);
            this.btnKetCa.TabIndex = 3;
            this.btnKetCa.Text = "Kết Ca";
            this.btnKetCa.Click += new System.EventHandler(this.btnKetCa_Click);
            // 
            // btnDatTruoc
            // 
            this.btnDatTruoc.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatTruoc.Appearance.Options.UseFont = true;
            this.btnDatTruoc.Location = new System.Drawing.Point(100, 26);
            this.btnDatTruoc.Name = "btnDatTruoc";
            this.btnDatTruoc.Size = new System.Drawing.Size(98, 36);
            this.btnDatTruoc.TabIndex = 0;
            // 
            // btnTrong
            // 
            this.btnTrong.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrong.Appearance.Options.UseFont = true;
            this.btnTrong.Location = new System.Drawing.Point(7, 26);
            this.btnTrong.Name = "btnTrong";
            this.btnTrong.Size = new System.Drawing.Size(87, 36);
            this.btnTrong.TabIndex = 0;
            // 
            // panelControl3
            // 
            this.panelControl3.Controls.Add(this.pictureBox1);
            this.panelControl3.Controls.Add(this.lblDiaChi);
            this.panelControl3.Controls.Add(this.lblDienThoai);
            this.panelControl3.Controls.Add(this.lblTenCongTy);
            this.panelControl3.Controls.Add(this.labelControl10);
            this.panelControl3.Location = new System.Drawing.Point(571, 4);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(728, 105);
            this.panelControl3.TabIndex = 6;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(18, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(157, 94);
            this.pictureBox1.TabIndex = 3;
            this.pictureBox1.TabStop = false;
            // 
            // lblDiaChi
            // 
            this.lblDiaChi.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiaChi.Location = new System.Drawing.Point(219, 53);
            this.lblDiaChi.Name = "lblDiaChi";
            this.lblDiaChi.Size = new System.Drawing.Size(44, 18);
            this.lblDiaChi.TabIndex = 1;
            this.lblDiaChi.Text = "Địa Chỉ";
            // 
            // lblDienThoai
            // 
            this.lblDienThoai.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDienThoai.Location = new System.Drawing.Point(290, 78);
            this.lblDienThoai.Name = "lblDienThoai";
            this.lblDienThoai.Size = new System.Drawing.Size(110, 18);
            this.lblDienThoai.TabIndex = 1;
            this.lblDienThoai.Text = "02966275595";
            // 
            // lblTenCongTy
            // 
            this.lblTenCongTy.Appearance.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenCongTy.Location = new System.Drawing.Point(314, 34);
            this.lblTenCongTy.Name = "lblTenCongTy";
            this.lblTenCongTy.Size = new System.Drawing.Size(82, 18);
            this.lblTenCongTy.TabIndex = 1;
            this.lblTenCongTy.Text = "tên công ty";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(259, 7);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(270, 21);
            this.labelControl10.TabIndex = 0;
            this.labelControl10.Text = "HỆ THỐNG QUẢN LÝ BÁN HÀNG";
            // 
            // menuBan
            // 
            this.menuBan.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonChonMon),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonDatBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonXoaBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonChuyenBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonTachBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonGopBan)});
            this.menuBan.Manager = this.barManager1;
            this.menuBan.Name = "menuBan";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // frmBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1311, 698);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.FormBorderEffect = DevExpress.XtraEditors.FormBorderEffect.Shadow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "frmBanHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HỆ THỐNG QUẢN LÝ BÁN HÀNG 2.0 (CÔNG TY GPM VIỆT NAM)";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmBanHang_FormClosing);
            this.Load += new System.EventHandler(this.frmBanHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoa)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            this.panelControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTenKhachHang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cmbHinhThucGiamGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGiaHoaDon.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemTichLuy.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienThoi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachThanhToan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachCanTra.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGiaDiem.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongGiamGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongTien.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCTHD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemTextEdit1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnXoaMonAn)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabControlDanhSach)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            this.groupControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            this.panelControl3.ResumeLayout(false);
            this.panelControl3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.menuBan)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private DevExpress.XtraEditors.SimpleButton btnTrong;
        private DevExpress.XtraEditors.SimpleButton btnCoNguoi;
        private DevExpress.XtraEditors.SimpleButton btnDatTruoc;
        private DevExpress.XtraEditors.LabelControl txtTyLyPhucVu;
        private DevExpress.XtraBars.PopupMenu menuBan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonXoaBan;
        private DevExpress.XtraBars.BarButtonItem barButtonChuyenBan;
        private DevExpress.XtraBars.BarButtonItem barButtonGopBan;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonDatBan;
        private DevExpress.XtraBars.BarButtonItem barButtonChonMon;
        private DevExpress.XtraBars.BarButtonItem barButtonTachBan;
        private DevExpress.XtraEditors.LabelControl txtTenDangNhap;
        private System.Windows.Forms.Timer timer1;
        private DevExpress.XtraEditors.LabelControl txtGioVao;
        private DevExpress.XtraEditors.SimpleButton btnKetCa;
        private DevExpress.XtraEditors.SimpleButton btnTachHoaDon;
        private DevExpress.XtraEditors.SimpleButton btnThanhToan;
        private DevExpress.XtraBars.BarButtonItem barButtonTinhGio;
        private DevExpress.XtraTab.XtraTabControl xtraTabControlDanhSach;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnXoa;
        private DevExpress.XtraEditors.LabelControl lblTenBan;
        private DevExpress.XtraEditors.LabelControl lblTime;
        private DevExpress.XtraEditors.LabelControl lblNgay;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraGrid.GridControl gridControlCTHD;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private DevExpress.XtraGrid.Columns.GridColumn btnXoaHangHoa;
        private DevExpress.XtraEditors.Repository.RepositoryItemButtonEdit btnXoaMonAn;
        private DevExpress.XtraEditors.LabelControl lblTenCongTy;
        private DevExpress.XtraEditors.LabelControl lblDiaChi;
        private DevExpress.XtraEditors.LabelControl lblDienThoai;
        private System.Windows.Forms.PictureBox pictureBox1;
        private DevExpress.XtraEditors.SimpleButton btnInTam;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.SpinEdit txtTongTien;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.SpinEdit txtKhachCanTra;
        private DevExpress.XtraEditors.SpinEdit txtGiamGia;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.SpinEdit txtTienThoi;
        private DevExpress.XtraEditors.SpinEdit txtKhachThanhToan;
        private DevExpress.XtraEditors.ComboBoxEdit cmbHinhThucGiamGia;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraEditors.SimpleButton btnMayIn;
        private DevExpress.XtraEditors.SimpleButton btnInPhaChe;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraEditors.Repository.RepositoryItemTextEdit repositoryItemTextEdit1;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SpinEdit txtDiemTichLuy;
        private DevExpress.XtraEditors.GridLookUpEdit cmbTenKhachHang;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn15;
        private DevExpress.XtraEditors.SimpleButton btnThemKhachHang;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.SpinEdit txtGiamGiaDiem;
        private DevExpress.XtraEditors.SpinEdit txtTongGiamGia;
        private DevExpress.XtraEditors.SpinEdit txtGiamGiaHoaDon;

    }
}