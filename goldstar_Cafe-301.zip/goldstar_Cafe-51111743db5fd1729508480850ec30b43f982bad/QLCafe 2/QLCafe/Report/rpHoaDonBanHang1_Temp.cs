﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QLCafe.Report
{
    public partial class rpHoaDonBanHang1_Temp : DevExpress.XtraReports.UI.XtraReport
    {
        public rpHoaDonBanHang1_Temp()
        {
            InitializeComponent();
        }

    }
}
