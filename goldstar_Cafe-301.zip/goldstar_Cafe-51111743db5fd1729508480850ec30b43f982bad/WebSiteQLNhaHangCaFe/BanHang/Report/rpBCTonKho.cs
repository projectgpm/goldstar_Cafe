﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace BanHang.Report
{
    public partial class rpBCTonKho : DevExpress.XtraReports.UI.XtraReport
    {
        public rpBCTonKho()
        {
            InitializeComponent();
        }

    }
}
