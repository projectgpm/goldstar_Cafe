﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace QLCafe.Report
{
    public partial class rpHoaDonBanHang2 : DevExpress.XtraReports.UI.XtraReport
    {
        public rpHoaDonBanHang2()
        {
            InitializeComponent();
        }

    }
}
