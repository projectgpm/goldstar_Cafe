﻿namespace QLCafe
{
    partial class frmKichHoat
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmKichHoat));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.btnHuy = new DevExpress.XtraEditors.SimpleButton();
            this.btnKichHoat = new DevExpress.XtraEditors.SimpleButton();
            this.txtSoE = new DevExpress.XtraEditors.TextEdit();
            this.txtSoD = new DevExpress.XtraEditors.TextEdit();
            this.txtSoC = new DevExpress.XtraEditors.TextEdit();
            this.txtSoB = new DevExpress.XtraEditors.TextEdit();
            this.txtSoA = new DevExpress.XtraEditors.TextEdit();
            this.label1 = new System.Windows.Forms.Label();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.linkLienHe = new System.Windows.Forms.LinkLabel();
            this.label5 = new System.Windows.Forms.Label();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoE.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoD.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoC.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoB.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoA.Properties)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.labelControl6);
            this.panelControl1.Controls.Add(this.labelControl5);
            this.panelControl1.Controls.Add(this.labelControl4);
            this.panelControl1.Controls.Add(this.labelControl3);
            this.panelControl1.Controls.Add(this.btnHuy);
            this.panelControl1.Controls.Add(this.btnKichHoat);
            this.panelControl1.Controls.Add(this.txtSoE);
            this.panelControl1.Controls.Add(this.txtSoD);
            this.panelControl1.Controls.Add(this.txtSoC);
            this.panelControl1.Controls.Add(this.txtSoB);
            this.panelControl1.Controls.Add(this.txtSoA);
            this.panelControl1.Controls.Add(this.label1);
            this.panelControl1.Controls.Add(this.labelControl2);
            this.panelControl1.Controls.Add(this.linkLienHe);
            this.panelControl1.Controls.Add(this.label5);
            this.panelControl1.Controls.Add(this.labelControl1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(668, 253);
            this.panelControl1.TabIndex = 0;
            // 
            // labelControl6
            // 
            this.labelControl6.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.labelControl6.Location = new System.Drawing.Point(523, 110);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(5, 18);
            this.labelControl6.TabIndex = 17;
            this.labelControl6.Text = "-";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.labelControl5.Location = new System.Drawing.Point(393, 110);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(5, 18);
            this.labelControl5.TabIndex = 16;
            this.labelControl5.Text = "-";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.labelControl4.Location = new System.Drawing.Point(265, 110);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(5, 18);
            this.labelControl4.TabIndex = 15;
            this.labelControl4.Text = "-";
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.labelControl3.Location = new System.Drawing.Point(138, 110);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(5, 18);
            this.labelControl3.TabIndex = 15;
            this.labelControl3.Text = "-";
            // 
            // btnHuy
            // 
            this.btnHuy.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.btnHuy.Appearance.Options.UseFont = true;
            this.btnHuy.Image = ((System.Drawing.Image)(resources.GetObject("btnHuy.Image")));
            this.btnHuy.Location = new System.Drawing.Point(348, 167);
            this.btnHuy.Name = "btnHuy";
            this.btnHuy.Size = new System.Drawing.Size(92, 28);
            this.btnHuy.TabIndex = 14;
            this.btnHuy.Text = "Hủy bỏ";
            this.btnHuy.Click += new System.EventHandler(this.btnHuy_Click);
            // 
            // btnKichHoat
            // 
            this.btnKichHoat.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.btnKichHoat.Appearance.Options.UseFont = true;
            this.btnKichHoat.Image = ((System.Drawing.Image)(resources.GetObject("btnKichHoat.Image")));
            this.btnKichHoat.Location = new System.Drawing.Point(231, 167);
            this.btnKichHoat.Name = "btnKichHoat";
            this.btnKichHoat.Size = new System.Drawing.Size(92, 28);
            this.btnKichHoat.TabIndex = 14;
            this.btnKichHoat.Text = "Kích hoạt";
            this.btnKichHoat.Click += new System.EventHandler(this.btnKichHoat_Click);
            // 
            // txtSoE
            // 
            this.txtSoE.Location = new System.Drawing.Point(538, 107);
            this.txtSoE.Name = "txtSoE";
            this.txtSoE.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtSoE.Properties.Appearance.Options.UseFont = true;
            this.txtSoE.Properties.MaxLength = 5;
            this.txtSoE.Size = new System.Drawing.Size(100, 24);
            this.txtSoE.TabIndex = 13;
            // 
            // txtSoD
            // 
            this.txtSoD.Location = new System.Drawing.Point(412, 107);
            this.txtSoD.Name = "txtSoD";
            this.txtSoD.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtSoD.Properties.Appearance.Options.UseFont = true;
            this.txtSoD.Properties.MaxLength = 5;
            this.txtSoD.Size = new System.Drawing.Size(100, 24);
            this.txtSoD.TabIndex = 13;
            // 
            // txtSoC
            // 
            this.txtSoC.Location = new System.Drawing.Point(281, 107);
            this.txtSoC.Name = "txtSoC";
            this.txtSoC.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtSoC.Properties.Appearance.Options.UseFont = true;
            this.txtSoC.Properties.MaxLength = 5;
            this.txtSoC.Size = new System.Drawing.Size(100, 24);
            this.txtSoC.TabIndex = 13;
            // 
            // txtSoB
            // 
            this.txtSoB.Location = new System.Drawing.Point(154, 107);
            this.txtSoB.Name = "txtSoB";
            this.txtSoB.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtSoB.Properties.Appearance.Options.UseFont = true;
            this.txtSoB.Properties.MaxLength = 5;
            this.txtSoB.Size = new System.Drawing.Size(100, 24);
            this.txtSoB.TabIndex = 13;
            // 
            // txtSoA
            // 
            this.txtSoA.Location = new System.Drawing.Point(27, 107);
            this.txtSoA.Name = "txtSoA";
            this.txtSoA.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.txtSoA.Properties.Appearance.Options.UseFont = true;
            this.txtSoA.Properties.MaxLength = 5;
            this.txtSoA.Size = new System.Drawing.Size(100, 24);
            this.txtSoA.TabIndex = 13;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(409, 216);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(190, 18);
            this.label1.TabIndex = 12;
            this.label1.Text = "Điện thoại : 02966.275.595 ";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 11F);
            this.labelControl2.Location = new System.Drawing.Point(12, 70);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(74, 18);
            this.labelControl2.TabIndex = 11;
            this.labelControl2.Text = "NHẬP KEY:";
            // 
            // linkLienHe
            // 
            this.linkLienHe.AutoSize = true;
            this.linkLienHe.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.linkLienHe.Location = new System.Drawing.Point(194, 216);
            this.linkLienHe.Name = "linkLienHe";
            this.linkLienHe.Size = new System.Drawing.Size(182, 18);
            this.linkLienHe.TabIndex = 10;
            this.linkLienHe.TabStop = true;
            this.linkLienHe.Text = "CÔNG TY GPM VIỆT NAM";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(41, 216);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(156, 18);
            this.label5.TabIndex = 9;
            this.label5.Text = "Mọi chi tiết xin liên hệ :";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 12.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.labelControl1.Location = new System.Drawing.Point(14, 12);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(638, 21);
            this.labelControl1.TabIndex = 8;
            this.labelControl1.Text = "HỆ THỐNG KÍCH HOẠT BẢN QUYỀN DO CÔNG TY GPM VIỆT NAM CUNG CẤP";
            // 
            // frmKichHoat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(668, 253);
            this.Controls.Add(this.panelControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmKichHoat";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MÀN HÌNH KÍCH HOẠT BẢN QUYỀN";
            this.Load += new System.EventHandler(this.frmKichHoat_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            this.panelControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoE.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoD.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoC.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoB.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSoA.Properties)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private System.Windows.Forms.LinkLabel linkLienHe;
        private System.Windows.Forms.Label label5;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private System.Windows.Forms.Label label1;
        private DevExpress.XtraEditors.TextEdit txtSoE;
        private DevExpress.XtraEditors.TextEdit txtSoD;
        private DevExpress.XtraEditors.TextEdit txtSoC;
        private DevExpress.XtraEditors.TextEdit txtSoB;
        private DevExpress.XtraEditors.TextEdit txtSoA;
        private DevExpress.XtraEditors.SimpleButton btnKichHoat;
        private DevExpress.XtraEditors.SimpleButton btnHuy;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;

    }
}