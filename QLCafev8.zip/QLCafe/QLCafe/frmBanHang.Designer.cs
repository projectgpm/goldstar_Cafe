﻿namespace QLCafe
{
    partial class frmBanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBanHang));
            this.panelControl1 = new DevExpress.XtraEditors.PanelControl();
            this.groupControl4 = new DevExpress.XtraEditors.GroupControl();
            this.txtGioVao = new DevExpress.XtraEditors.LabelControl();
            this.lblTime = new DevExpress.XtraEditors.LabelControl();
            this.txtTenDangNhap = new DevExpress.XtraEditors.LabelControl();
            this.txtTyLyPhucVu = new DevExpress.XtraEditors.LabelControl();
            this.btnCoNguoi = new DevExpress.XtraEditors.SimpleButton();
            this.btnKetCa = new DevExpress.XtraEditors.SimpleButton();
            this.btnDatTruoc = new DevExpress.XtraEditors.SimpleButton();
            this.btnTrong = new DevExpress.XtraEditors.SimpleButton();
            this.lableTongTien = new DevExpress.XtraEditors.PanelControl();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.btnThemKhachHang = new DevExpress.XtraEditors.SimpleButton();
            this.txtDiem = new DevExpress.XtraEditors.LabelControl();
            this.txtCMND = new DevExpress.XtraEditors.LabelControl();
            this.txtDienThoai = new DevExpress.XtraEditors.LabelControl();
            this.txtMaKhachHang = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.cmbTenKhachHang = new DevExpress.XtraEditors.GridLookUpEdit();
            this.barManager1 = new DevExpress.XtraBars.BarManager(this.components);
            this.barDockControlTop = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlBottom = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlLeft = new DevExpress.XtraBars.BarDockControl();
            this.barDockControlRight = new DevExpress.XtraBars.BarDockControl();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonXoaBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonChuyenBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonGopBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem5 = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonDatBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonTachBan = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonChonMon = new DevExpress.XtraBars.BarButtonItem();
            this.gridLookUpEdit1View = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.btnInHoaDon = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.txtTienThoi = new DevExpress.XtraEditors.SpinEdit();
            this.txtKhachThanhToan = new DevExpress.XtraEditors.SpinEdit();
            this.txtKhachCanTra = new DevExpress.XtraEditors.SpinEdit();
            this.txtGiamGia = new DevExpress.XtraEditors.SpinEdit();
            this.txtDiemTichLuy = new DevExpress.XtraEditors.SpinEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtTongTien = new DevExpress.XtraEditors.SpinEdit();
            this.panelControl3 = new DevExpress.XtraEditors.PanelControl();
            this.panelControl2 = new DevExpress.XtraEditors.PanelControl();
            this.gridControlCTHD = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.gridColumn1 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn2 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn3 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn4 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn5 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn6 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn7 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn8 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn9 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.tblTable1 = new System.Windows.Forms.FlowLayoutPanel();
            this.menuBan = new DevExpress.XtraBars.PopupMenu(this.components);
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.gridColumn10 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn11 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn12 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn13 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.gridColumn14 = new DevExpress.XtraGrid.Columns.GridColumn();
            this.repositoryItemSpinEdit1 = new DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).BeginInit();
            this.panelControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).BeginInit();
            this.groupControl4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lableTongTien)).BeginInit();
            this.lableTongTien.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTenKhachHang.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).BeginInit();
            this.tableLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienThoi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachThanhToan.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachCanTra.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemTichLuy.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongTien.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).BeginInit();
            this.panelControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCTHD)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.menuBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).BeginInit();
            this.SuspendLayout();
            // 
            // panelControl1
            // 
            this.panelControl1.Controls.Add(this.groupControl4);
            this.panelControl1.Controls.Add(this.lableTongTien);
            this.panelControl1.Controls.Add(this.panelControl3);
            this.panelControl1.Controls.Add(this.panelControl2);
            this.panelControl1.Controls.Add(this.groupControl1);
            this.panelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panelControl1.Location = new System.Drawing.Point(0, 0);
            this.panelControl1.Name = "panelControl1";
            this.panelControl1.Size = new System.Drawing.Size(1307, 679);
            this.panelControl1.TabIndex = 0;
            // 
            // groupControl4
            // 
            this.groupControl4.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl4.AppearanceCaption.Options.UseFont = true;
            this.groupControl4.Controls.Add(this.txtGioVao);
            this.groupControl4.Controls.Add(this.lblTime);
            this.groupControl4.Controls.Add(this.txtTenDangNhap);
            this.groupControl4.Controls.Add(this.txtTyLyPhucVu);
            this.groupControl4.Controls.Add(this.btnCoNguoi);
            this.groupControl4.Controls.Add(this.btnKetCa);
            this.groupControl4.Controls.Add(this.btnDatTruoc);
            this.groupControl4.Controls.Add(this.btnTrong);
            this.groupControl4.Location = new System.Drawing.Point(5, 4);
            this.groupControl4.Name = "groupControl4";
            this.groupControl4.Size = new System.Drawing.Size(560, 105);
            this.groupControl4.TabIndex = 8;
            this.groupControl4.Text = "Trạng Thái";
            // 
            // txtGioVao
            // 
            this.txtGioVao.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGioVao.Location = new System.Drawing.Point(140, 78);
            this.txtGioVao.Name = "txtGioVao";
            this.txtGioVao.Size = new System.Drawing.Size(0, 18);
            this.txtGioVao.TabIndex = 6;
            // 
            // lblTime
            // 
            this.lblTime.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTime.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.lblTime.Location = new System.Drawing.Point(431, 42);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(81, 18);
            this.lblTime.TabIndex = 5;
            this.lblTime.Text = "labelControl6";
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDangNhap.Location = new System.Drawing.Point(359, 78);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.Size = new System.Drawing.Size(81, 18);
            this.txtTenDangNhap.TabIndex = 4;
            this.txtTenDangNhap.Text = "labelControl6";
            // 
            // txtTyLyPhucVu
            // 
            this.txtTyLyPhucVu.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTyLyPhucVu.Location = new System.Drawing.Point(10, 78);
            this.txtTyLyPhucVu.Name = "txtTyLyPhucVu";
            this.txtTyLyPhucVu.Size = new System.Drawing.Size(81, 18);
            this.txtTyLyPhucVu.TabIndex = 1;
            this.txtTyLyPhucVu.Text = "labelControl5";
            // 
            // btnCoNguoi
            // 
            this.btnCoNguoi.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCoNguoi.Appearance.Options.UseFont = true;
            this.btnCoNguoi.Location = new System.Drawing.Point(204, 26);
            this.btnCoNguoi.Name = "btnCoNguoi";
            this.btnCoNguoi.Size = new System.Drawing.Size(98, 36);
            this.btnCoNguoi.TabIndex = 0;
            // 
            // btnKetCa
            // 
            this.btnKetCa.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnKetCa.Appearance.Options.UseFont = true;
            this.btnKetCa.Image = ((System.Drawing.Image)(resources.GetObject("btnKetCa.Image")));
            this.btnKetCa.Location = new System.Drawing.Point(308, 25);
            this.btnKetCa.Name = "btnKetCa";
            this.btnKetCa.Size = new System.Drawing.Size(102, 36);
            this.btnKetCa.TabIndex = 3;
            this.btnKetCa.Text = "Kết Ca";
            // 
            // btnDatTruoc
            // 
            this.btnDatTruoc.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatTruoc.Appearance.Options.UseFont = true;
            this.btnDatTruoc.Location = new System.Drawing.Point(100, 26);
            this.btnDatTruoc.Name = "btnDatTruoc";
            this.btnDatTruoc.Size = new System.Drawing.Size(98, 36);
            this.btnDatTruoc.TabIndex = 0;
            // 
            // btnTrong
            // 
            this.btnTrong.Appearance.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTrong.Appearance.Options.UseFont = true;
            this.btnTrong.Location = new System.Drawing.Point(7, 26);
            this.btnTrong.Name = "btnTrong";
            this.btnTrong.Size = new System.Drawing.Size(87, 36);
            this.btnTrong.TabIndex = 0;
            // 
            // lableTongTien
            // 
            this.lableTongTien.Controls.Add(this.groupControl2);
            this.lableTongTien.Controls.Add(this.btnInHoaDon);
            this.lableTongTien.Controls.Add(this.simpleButton1);
            this.lableTongTien.Controls.Add(this.tableLayoutPanel1);
            this.lableTongTien.Location = new System.Drawing.Point(573, 417);
            this.lableTongTien.Name = "lableTongTien";
            this.lableTongTien.Size = new System.Drawing.Size(720, 248);
            this.lableTongTien.TabIndex = 7;
            // 
            // groupControl2
            // 
            this.groupControl2.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl2.AppearanceCaption.Options.UseFont = true;
            this.groupControl2.Controls.Add(this.btnThemKhachHang);
            this.groupControl2.Controls.Add(this.txtDiem);
            this.groupControl2.Controls.Add(this.txtCMND);
            this.groupControl2.Controls.Add(this.txtDienThoai);
            this.groupControl2.Controls.Add(this.txtMaKhachHang);
            this.groupControl2.Controls.Add(this.labelControl13);
            this.groupControl2.Controls.Add(this.labelControl11);
            this.groupControl2.Controls.Add(this.labelControl10);
            this.groupControl2.Controls.Add(this.labelControl9);
            this.groupControl2.Controls.Add(this.labelControl7);
            this.groupControl2.Controls.Add(this.cmbTenKhachHang);
            this.groupControl2.Location = new System.Drawing.Point(397, 2);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(323, 184);
            this.groupControl2.TabIndex = 4;
            this.groupControl2.Text = "Thông tin khách hàng";
            // 
            // btnThemKhachHang
            // 
            this.btnThemKhachHang.Image = ((System.Drawing.Image)(resources.GetObject("btnThemKhachHang.Image")));
            this.btnThemKhachHang.Location = new System.Drawing.Point(291, 56);
            this.btnThemKhachHang.Name = "btnThemKhachHang";
            this.btnThemKhachHang.Size = new System.Drawing.Size(25, 27);
            this.btnThemKhachHang.TabIndex = 3;
            this.btnThemKhachHang.Click += new System.EventHandler(this.btnThemKhachHang_Click);
            // 
            // txtDiem
            // 
            this.txtDiem.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiem.Location = new System.Drawing.Point(120, 154);
            this.txtDiem.Name = "txtDiem";
            this.txtDiem.Size = new System.Drawing.Size(170, 18);
            this.txtDiem.TabIndex = 1;
            this.txtDiem.Text = "..................................";
            // 
            // txtCMND
            // 
            this.txtCMND.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCMND.Location = new System.Drawing.Point(120, 121);
            this.txtCMND.Name = "txtCMND";
            this.txtCMND.Size = new System.Drawing.Size(170, 18);
            this.txtCMND.TabIndex = 1;
            this.txtCMND.Text = "..................................";
            // 
            // txtDienThoai
            // 
            this.txtDienThoai.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDienThoai.Location = new System.Drawing.Point(120, 89);
            this.txtDienThoai.Name = "txtDienThoai";
            this.txtDienThoai.Size = new System.Drawing.Size(170, 18);
            this.txtDienThoai.TabIndex = 1;
            this.txtDienThoai.Text = "..................................";
            // 
            // txtMaKhachHang
            // 
            this.txtMaKhachHang.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaKhachHang.Location = new System.Drawing.Point(120, 30);
            this.txtMaKhachHang.Name = "txtMaKhachHang";
            this.txtMaKhachHang.Size = new System.Drawing.Size(170, 18);
            this.txtMaKhachHang.TabIndex = 1;
            this.txtMaKhachHang.Text = "..................................";
            // 
            // labelControl13
            // 
            this.labelControl13.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl13.Location = new System.Drawing.Point(5, 154);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(98, 18);
            this.labelControl13.TabIndex = 0;
            this.labelControl13.Text = "Điểm Tích Lũy:";
            // 
            // labelControl11
            // 
            this.labelControl11.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl11.Location = new System.Drawing.Point(5, 123);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(46, 18);
            this.labelControl11.TabIndex = 0;
            this.labelControl11.Text = "CMND:";
            // 
            // labelControl10
            // 
            this.labelControl10.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl10.Location = new System.Drawing.Point(5, 92);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(74, 18);
            this.labelControl10.TabIndex = 0;
            this.labelControl10.Text = "Điện Thoại:";
            // 
            // labelControl9
            // 
            this.labelControl9.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl9.Location = new System.Drawing.Point(5, 61);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(115, 18);
            this.labelControl9.TabIndex = 0;
            this.labelControl9.Text = "Tên Khách Hàng:";
            // 
            // labelControl7
            // 
            this.labelControl7.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl7.Location = new System.Drawing.Point(5, 30);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(109, 18);
            this.labelControl7.TabIndex = 0;
            this.labelControl7.Text = "Mã Khách Hàng:";
            // 
            // cmbTenKhachHang
            // 
            this.cmbTenKhachHang.Location = new System.Drawing.Point(121, 58);
            this.cmbTenKhachHang.MenuManager = this.barManager1;
            this.cmbTenKhachHang.Name = "cmbTenKhachHang";
            this.cmbTenKhachHang.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTenKhachHang.Properties.Appearance.Options.UseFont = true;
            this.cmbTenKhachHang.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.cmbTenKhachHang.Properties.NullText = "Chọn tên khách hàng";
            this.cmbTenKhachHang.Properties.View = this.gridLookUpEdit1View;
            this.cmbTenKhachHang.Size = new System.Drawing.Size(170, 24);
            this.cmbTenKhachHang.TabIndex = 2;
            this.cmbTenKhachHang.EditValueChanged += new System.EventHandler(this.cmbTenKhachHang_EditValueChanged);
            // 
            // barManager1
            // 
            this.barManager1.DockControls.Add(this.barDockControlTop);
            this.barManager1.DockControls.Add(this.barDockControlBottom);
            this.barManager1.DockControls.Add(this.barDockControlLeft);
            this.barManager1.DockControls.Add(this.barDockControlRight);
            this.barManager1.Form = this;
            this.barManager1.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.barButtonItem1,
            this.barButtonXoaBan,
            this.barButtonChuyenBan,
            this.barButtonGopBan,
            this.barButtonItem5,
            this.barButtonDatBan,
            this.barButtonTachBan,
            this.barButtonChonMon});
            this.barManager1.MaxItemId = 8;
            // 
            // barDockControlTop
            // 
            this.barDockControlTop.CausesValidation = false;
            this.barDockControlTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.barDockControlTop.Location = new System.Drawing.Point(0, 0);
            this.barDockControlTop.Size = new System.Drawing.Size(1307, 0);
            // 
            // barDockControlBottom
            // 
            this.barDockControlBottom.CausesValidation = false;
            this.barDockControlBottom.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.barDockControlBottom.Location = new System.Drawing.Point(0, 679);
            this.barDockControlBottom.Size = new System.Drawing.Size(1307, 0);
            // 
            // barDockControlLeft
            // 
            this.barDockControlLeft.CausesValidation = false;
            this.barDockControlLeft.Dock = System.Windows.Forms.DockStyle.Left;
            this.barDockControlLeft.Location = new System.Drawing.Point(0, 0);
            this.barDockControlLeft.Size = new System.Drawing.Size(0, 679);
            // 
            // barDockControlRight
            // 
            this.barDockControlRight.CausesValidation = false;
            this.barDockControlRight.Dock = System.Windows.Forms.DockStyle.Right;
            this.barDockControlRight.Location = new System.Drawing.Point(1307, 0);
            this.barDockControlRight.Size = new System.Drawing.Size(0, 679);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Đặt Bàn";
            this.barButtonItem1.Id = 0;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // barButtonXoaBan
            // 
            this.barButtonXoaBan.Caption = "Xóa Bàn";
            this.barButtonXoaBan.Id = 1;
            this.barButtonXoaBan.ImageUri.Uri = "Cancel";
            this.barButtonXoaBan.Name = "barButtonXoaBan";
            this.barButtonXoaBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonXoaBan_ItemClick);
            // 
            // barButtonChuyenBan
            // 
            this.barButtonChuyenBan.Caption = "Chuyển Bàn";
            this.barButtonChuyenBan.Id = 2;
            this.barButtonChuyenBan.ImageUri.Uri = "Replace";
            this.barButtonChuyenBan.Name = "barButtonChuyenBan";
            this.barButtonChuyenBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonChuyenBan_ItemClick);
            // 
            // barButtonGopBan
            // 
            this.barButtonGopBan.Caption = "Gộp Bàn";
            this.barButtonGopBan.Id = 3;
            this.barButtonGopBan.ImageUri.Uri = "Refresh";
            this.barButtonGopBan.Name = "barButtonGopBan";
            this.barButtonGopBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonGopBan_ItemClick);
            // 
            // barButtonItem5
            // 
            this.barButtonItem5.Id = 4;
            this.barButtonItem5.Name = "barButtonItem5";
            // 
            // barButtonDatBan
            // 
            this.barButtonDatBan.Caption = "Đặt Bàn";
            this.barButtonDatBan.Id = 5;
            this.barButtonDatBan.ImageUri.Uri = "Apply";
            this.barButtonDatBan.Name = "barButtonDatBan";
            this.barButtonDatBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonDatBan_ItemClick);
            // 
            // barButtonTachBan
            // 
            this.barButtonTachBan.Caption = "Tách Bàn";
            this.barButtonTachBan.Id = 6;
            this.barButtonTachBan.ImageUri.Uri = "Cut";
            this.barButtonTachBan.Name = "barButtonTachBan";
            this.barButtonTachBan.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonTachBan_ItemClick);
            // 
            // barButtonChonMon
            // 
            this.barButtonChonMon.Caption = "Gọi Món";
            this.barButtonChonMon.Id = 7;
            this.barButtonChonMon.ImageUri.Uri = "Edit";
            this.barButtonChonMon.Name = "barButtonChonMon";
            this.barButtonChonMon.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonChonMon_ItemClick);
            // 
            // gridLookUpEdit1View
            // 
            this.gridLookUpEdit1View.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn10,
            this.gridColumn11,
            this.gridColumn12,
            this.gridColumn13,
            this.gridColumn14});
            this.gridLookUpEdit1View.FocusRectStyle = DevExpress.XtraGrid.Views.Grid.DrawFocusRectStyle.RowFocus;
            this.gridLookUpEdit1View.Name = "gridLookUpEdit1View";
            this.gridLookUpEdit1View.OptionsDetail.DetailMode = DevExpress.XtraGrid.Views.Grid.DetailMode.Default;
            this.gridLookUpEdit1View.OptionsSelection.EnableAppearanceFocusedCell = false;
            this.gridLookUpEdit1View.OptionsView.ShowAutoFilterRow = true;
            this.gridLookUpEdit1View.OptionsView.ShowFilterPanelMode = DevExpress.XtraGrid.Views.Base.ShowFilterPanelMode.Never;
            this.gridLookUpEdit1View.OptionsView.ShowGroupPanel = false;
            // 
            // btnInHoaDon
            // 
            this.btnInHoaDon.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInHoaDon.Appearance.Options.UseFont = true;
            this.btnInHoaDon.Image = ((System.Drawing.Image)(resources.GetObject("btnInHoaDon.Image")));
            this.btnInHoaDon.Location = new System.Drawing.Point(433, 199);
            this.btnInHoaDon.Name = "btnInHoaDon";
            this.btnInHoaDon.Size = new System.Drawing.Size(120, 36);
            this.btnInHoaDon.TabIndex = 3;
            this.btnInHoaDon.Text = "In Hóa Đơn";
            // 
            // simpleButton1
            // 
            this.simpleButton1.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.simpleButton1.Appearance.Options.UseFont = true;
            this.simpleButton1.Image = ((System.Drawing.Image)(resources.GetObject("simpleButton1.Image")));
            this.simpleButton1.Location = new System.Drawing.Point(569, 199);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(129, 36);
            this.simpleButton1.TabIndex = 3;
            this.simpleButton1.Text = "Thanh Toán";
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayoutPanel1.ColumnCount = 2;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 43.71585F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 218F));
            this.tableLayoutPanel1.Controls.Add(this.txtTienThoi, 1, 5);
            this.tableLayoutPanel1.Controls.Add(this.txtKhachThanhToan, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.txtKhachCanTra, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.txtGiamGia, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.txtDiemTichLuy, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelControl3, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.labelControl2, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.labelControl8, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.labelControl5, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.labelControl4, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.labelControl1, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.txtTongTien, 1, 0);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(0, 0);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 48.80952F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 51.19048F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 39F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 42F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(391, 245);
            this.tableLayoutPanel1.TabIndex = 2;
            // 
            // txtTienThoi
            // 
            this.txtTienThoi.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTienThoi.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTienThoi.Location = new System.Drawing.Point(175, 208);
            this.txtTienThoi.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtTienThoi.MenuManager = this.barManager1;
            this.txtTienThoi.Name = "txtTienThoi";
            this.txtTienThoi.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTienThoi.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTienThoi.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtTienThoi.Properties.Appearance.Options.UseBackColor = true;
            this.txtTienThoi.Properties.Appearance.Options.UseFont = true;
            this.txtTienThoi.Properties.Appearance.Options.UseForeColor = true;
            this.txtTienThoi.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtTienThoi.Properties.DisplayFormat.FormatString = "{0:#,# đ}";
            this.txtTienThoi.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtTienThoi.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtTienThoi.Size = new System.Drawing.Size(212, 30);
            this.txtTienThoi.TabIndex = 22;
            // 
            // txtKhachThanhToan
            // 
            this.txtKhachThanhToan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtKhachThanhToan.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtKhachThanhToan.Location = new System.Drawing.Point(175, 165);
            this.txtKhachThanhToan.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtKhachThanhToan.MenuManager = this.barManager1;
            this.txtKhachThanhToan.Name = "txtKhachThanhToan";
            this.txtKhachThanhToan.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtKhachThanhToan.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhachThanhToan.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtKhachThanhToan.Properties.Appearance.Options.UseBackColor = true;
            this.txtKhachThanhToan.Properties.Appearance.Options.UseFont = true;
            this.txtKhachThanhToan.Properties.Appearance.Options.UseForeColor = true;
            this.txtKhachThanhToan.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtKhachThanhToan.Properties.DisplayFormat.FormatString = "{0:#,# đ}";
            this.txtKhachThanhToan.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtKhachThanhToan.Properties.EditFormat.FormatString = "{0:#,# đ}";
            this.txtKhachThanhToan.Properties.EditFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtKhachThanhToan.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtKhachThanhToan.Size = new System.Drawing.Size(212, 30);
            this.txtKhachThanhToan.TabIndex = 21;
            this.txtKhachThanhToan.EditValueChanged += new System.EventHandler(this.txtKhachThanhToan_EditValueChanged);
            // 
            // txtKhachCanTra
            // 
            this.txtKhachCanTra.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtKhachCanTra.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtKhachCanTra.Location = new System.Drawing.Point(175, 125);
            this.txtKhachCanTra.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtKhachCanTra.MenuManager = this.barManager1;
            this.txtKhachCanTra.Name = "txtKhachCanTra";
            this.txtKhachCanTra.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtKhachCanTra.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtKhachCanTra.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtKhachCanTra.Properties.Appearance.Options.UseBackColor = true;
            this.txtKhachCanTra.Properties.Appearance.Options.UseFont = true;
            this.txtKhachCanTra.Properties.Appearance.Options.UseForeColor = true;
            this.txtKhachCanTra.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtKhachCanTra.Properties.DisplayFormat.FormatString = "{0:#,# đ}";
            this.txtKhachCanTra.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtKhachCanTra.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtKhachCanTra.Size = new System.Drawing.Size(212, 30);
            this.txtKhachCanTra.TabIndex = 20;
            // 
            // txtGiamGia
            // 
            this.txtGiamGia.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtGiamGia.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtGiamGia.Location = new System.Drawing.Point(175, 85);
            this.txtGiamGia.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtGiamGia.MenuManager = this.barManager1;
            this.txtGiamGia.Name = "txtGiamGia";
            this.txtGiamGia.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtGiamGia.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtGiamGia.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtGiamGia.Properties.Appearance.Options.UseBackColor = true;
            this.txtGiamGia.Properties.Appearance.Options.UseFont = true;
            this.txtGiamGia.Properties.Appearance.Options.UseForeColor = true;
            this.txtGiamGia.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtGiamGia.Properties.DisplayFormat.FormatString = "{0:#,# đ}";
            this.txtGiamGia.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtGiamGia.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtGiamGia.Size = new System.Drawing.Size(212, 30);
            this.txtGiamGia.TabIndex = 19;
            // 
            // txtDiemTichLuy
            // 
            this.txtDiemTichLuy.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtDiemTichLuy.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtDiemTichLuy.Location = new System.Drawing.Point(175, 45);
            this.txtDiemTichLuy.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtDiemTichLuy.MenuManager = this.barManager1;
            this.txtDiemTichLuy.Name = "txtDiemTichLuy";
            this.txtDiemTichLuy.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtDiemTichLuy.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiemTichLuy.Properties.Appearance.ForeColor = System.Drawing.Color.Blue;
            this.txtDiemTichLuy.Properties.Appearance.Options.UseBackColor = true;
            this.txtDiemTichLuy.Properties.Appearance.Options.UseFont = true;
            this.txtDiemTichLuy.Properties.Appearance.Options.UseForeColor = true;
            this.txtDiemTichLuy.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtDiemTichLuy.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtDiemTichLuy.Size = new System.Drawing.Size(212, 30);
            this.txtDiemTichLuy.TabIndex = 18;
            this.txtDiemTichLuy.EditValueChanged += new System.EventHandler(this.txtDiemTichLuy_EditValueChanged);
            // 
            // labelControl3
            // 
            this.labelControl3.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl3.Location = new System.Drawing.Point(4, 206);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl3.Size = new System.Drawing.Size(164, 35);
            this.labelControl3.TabIndex = 16;
            this.labelControl3.Text = "TIỀN THỒI";
            // 
            // labelControl2
            // 
            this.labelControl2.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl2.Location = new System.Drawing.Point(4, 163);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl2.Size = new System.Drawing.Size(164, 36);
            this.labelControl2.TabIndex = 12;
            this.labelControl2.Text = "KHÁCH THANH TOÁN";
            // 
            // labelControl8
            // 
            this.labelControl8.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl8.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl8.Location = new System.Drawing.Point(4, 123);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl8.Size = new System.Drawing.Size(164, 33);
            this.labelControl8.TabIndex = 9;
            this.labelControl8.Text = "KHÁCH CẦN TRẢ";
            // 
            // labelControl5
            // 
            this.labelControl5.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl5.Location = new System.Drawing.Point(4, 83);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl5.Size = new System.Drawing.Size(164, 33);
            this.labelControl5.TabIndex = 6;
            this.labelControl5.Text = "GIẢM GIÁ";
            // 
            // labelControl4
            // 
            this.labelControl4.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl4.Location = new System.Drawing.Point(4, 43);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl4.Size = new System.Drawing.Size(164, 33);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "ĐIỂM TÍCH LŨY";
            // 
            // labelControl1
            // 
            this.labelControl1.Appearance.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.labelControl1.Location = new System.Drawing.Point(4, 4);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Padding = new System.Windows.Forms.Padding(10, 0, 0, 0);
            this.labelControl1.Size = new System.Drawing.Size(164, 32);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "TỔNG TIỀN";
            // 
            // txtTongTien
            // 
            this.txtTongTien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtTongTien.EditValue = new decimal(new int[] {
            0,
            0,
            0,
            0});
            this.txtTongTien.Location = new System.Drawing.Point(175, 6);
            this.txtTongTien.Margin = new System.Windows.Forms.Padding(3, 5, 3, 3);
            this.txtTongTien.MenuManager = this.barManager1;
            this.txtTongTien.Name = "txtTongTien";
            this.txtTongTien.Properties.Appearance.BackColor = System.Drawing.Color.White;
            this.txtTongTien.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 15F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTongTien.Properties.Appearance.ForeColor = System.Drawing.Color.Red;
            this.txtTongTien.Properties.Appearance.Options.UseBackColor = true;
            this.txtTongTien.Properties.Appearance.Options.UseFont = true;
            this.txtTongTien.Properties.Appearance.Options.UseForeColor = true;
            this.txtTongTien.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.txtTongTien.Properties.DisplayFormat.FormatString = "{0:#,# đ}";
            this.txtTongTien.Properties.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.txtTongTien.Properties.LookAndFeel.SkinMaskColor = System.Drawing.Color.White;
            this.txtTongTien.Size = new System.Drawing.Size(212, 30);
            this.txtTongTien.TabIndex = 17;
            // 
            // panelControl3
            // 
            this.panelControl3.Location = new System.Drawing.Point(571, 4);
            this.panelControl3.Name = "panelControl3";
            this.panelControl3.Size = new System.Drawing.Size(722, 105);
            this.panelControl3.TabIndex = 6;
            // 
            // panelControl2
            // 
            this.panelControl2.Controls.Add(this.gridControlCTHD);
            this.panelControl2.Location = new System.Drawing.Point(571, 111);
            this.panelControl2.Name = "panelControl2";
            this.panelControl2.Size = new System.Drawing.Size(724, 302);
            this.panelControl2.TabIndex = 5;
            // 
            // gridControlCTHD
            // 
            this.gridControlCTHD.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridControlCTHD.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gridControlCTHD.Location = new System.Drawing.Point(2, 2);
            this.gridControlCTHD.MainView = this.gridView1;
            this.gridControlCTHD.MenuManager = this.barManager1;
            this.gridControlCTHD.Name = "gridControlCTHD";
            this.gridControlCTHD.RepositoryItems.AddRange(new DevExpress.XtraEditors.Repository.RepositoryItem[] {
            this.repositoryItemSpinEdit1});
            this.gridControlCTHD.Size = new System.Drawing.Size(720, 298);
            this.gridControlCTHD.TabIndex = 0;
            this.gridControlCTHD.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.Columns.AddRange(new DevExpress.XtraGrid.Columns.GridColumn[] {
            this.gridColumn1,
            this.gridColumn2,
            this.gridColumn3,
            this.gridColumn4,
            this.gridColumn5,
            this.gridColumn6,
            this.gridColumn7,
            this.gridColumn8,
            this.gridColumn9});
            this.gridView1.GridControl = this.gridControlCTHD;
            this.gridView1.Name = "gridView1";
            this.gridView1.OptionsDetail.DetailMode = DevExpress.XtraGrid.Views.Grid.DetailMode.Default;
            this.gridView1.OptionsView.ShowGroupPanel = false;
            // 
            // gridColumn1
            // 
            this.gridColumn1.Caption = "Mã Món";
            this.gridColumn1.FieldName = "MaHangHoa";
            this.gridColumn1.Name = "gridColumn1";
            this.gridColumn1.OptionsColumn.AllowEdit = false;
            this.gridColumn1.Visible = true;
            this.gridColumn1.VisibleIndex = 0;
            this.gridColumn1.Width = 52;
            // 
            // gridColumn2
            // 
            this.gridColumn2.Caption = "Tên Món";
            this.gridColumn2.FieldName = "TenHangHoa";
            this.gridColumn2.Name = "gridColumn2";
            this.gridColumn2.OptionsColumn.AllowEdit = false;
            this.gridColumn2.Visible = true;
            this.gridColumn2.VisibleIndex = 1;
            this.gridColumn2.Width = 90;
            // 
            // gridColumn3
            // 
            this.gridColumn3.Caption = "ĐVT";
            this.gridColumn3.FieldName = "DonViTinh";
            this.gridColumn3.Name = "gridColumn3";
            this.gridColumn3.OptionsColumn.AllowEdit = false;
            this.gridColumn3.Visible = true;
            this.gridColumn3.VisibleIndex = 2;
            this.gridColumn3.Width = 35;
            // 
            // gridColumn4
            // 
            this.gridColumn4.Caption = "Số Lượng";
            this.gridColumn4.ColumnEdit = this.repositoryItemSpinEdit1;
            this.gridColumn4.FieldName = "SoLuong";
            this.gridColumn4.Name = "gridColumn4";
            this.gridColumn4.ShowButtonMode = DevExpress.XtraGrid.Views.Base.ShowButtonModeEnum.ShowForFocusedRow;
            this.gridColumn4.Visible = true;
            this.gridColumn4.VisibleIndex = 3;
            this.gridColumn4.Width = 53;
            // 
            // gridColumn5
            // 
            this.gridColumn5.Caption = "Đơn Giá";
            this.gridColumn5.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn5.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn5.FieldName = "DonGia";
            this.gridColumn5.Name = "gridColumn5";
            this.gridColumn5.OptionsColumn.AllowEdit = false;
            this.gridColumn5.Visible = true;
            this.gridColumn5.VisibleIndex = 4;
            this.gridColumn5.Width = 69;
            // 
            // gridColumn6
            // 
            this.gridColumn6.Caption = "Phụ Thu Theo Giờ";
            this.gridColumn6.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn6.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn6.FieldName = "PhuThuGio";
            this.gridColumn6.Name = "gridColumn6";
            this.gridColumn6.OptionsColumn.AllowEdit = false;
            this.gridColumn6.Visible = true;
            this.gridColumn6.VisibleIndex = 5;
            this.gridColumn6.Width = 96;
            // 
            // gridColumn7
            // 
            this.gridColumn7.Caption = "Phụ Thu Theo Khu Vực";
            this.gridColumn7.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn7.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn7.FieldName = "PhuThuKhuVuc";
            this.gridColumn7.Name = "gridColumn7";
            this.gridColumn7.OptionsColumn.AllowEdit = false;
            this.gridColumn7.Visible = true;
            this.gridColumn7.VisibleIndex = 6;
            this.gridColumn7.Width = 125;
            // 
            // gridColumn8
            // 
            this.gridColumn8.Caption = "Giá Tổng";
            this.gridColumn8.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn8.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn8.FieldName = "GiaTong";
            this.gridColumn8.Name = "gridColumn8";
            this.gridColumn8.OptionsColumn.AllowEdit = false;
            this.gridColumn8.Visible = true;
            this.gridColumn8.VisibleIndex = 7;
            this.gridColumn8.Width = 82;
            // 
            // gridColumn9
            // 
            this.gridColumn9.Caption = "Thành Tiền";
            this.gridColumn9.DisplayFormat.FormatString = "{0:#,# đ}";
            this.gridColumn9.DisplayFormat.FormatType = DevExpress.Utils.FormatType.Custom;
            this.gridColumn9.FieldName = "ThanhTien";
            this.gridColumn9.Name = "gridColumn9";
            this.gridColumn9.OptionsColumn.AllowEdit = false;
            this.gridColumn9.Visible = true;
            this.gridColumn9.VisibleIndex = 8;
            this.gridColumn9.Width = 97;
            // 
            // groupControl1
            // 
            this.groupControl1.AppearanceCaption.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupControl1.AppearanceCaption.Options.UseFont = true;
            this.groupControl1.Controls.Add(this.tblTable1);
            this.groupControl1.Location = new System.Drawing.Point(5, 111);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(560, 556);
            this.groupControl1.TabIndex = 2;
            this.groupControl1.Text = "Danh Sách Bàn";
            // 
            // tblTable1
            // 
            this.tblTable1.AutoScroll = true;
            this.tblTable1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tblTable1.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tblTable1.Location = new System.Drawing.Point(2, 24);
            this.tblTable1.Name = "tblTable1";
            this.tblTable1.Size = new System.Drawing.Size(556, 530);
            this.tblTable1.TabIndex = 0;
            // 
            // menuBan
            // 
            this.menuBan.LinksPersistInfo.AddRange(new DevExpress.XtraBars.LinkPersistInfo[] {
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonChonMon),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonDatBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonXoaBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonChuyenBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonTachBan),
            new DevExpress.XtraBars.LinkPersistInfo(this.barButtonGopBan)});
            this.menuBan.Manager = this.barManager1;
            this.menuBan.Name = "menuBan";
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // gridColumn10
            // 
            this.gridColumn10.Caption = "Mã Khách Hàng";
            this.gridColumn10.FieldName = "MaKhachHang";
            this.gridColumn10.Name = "gridColumn10";
            this.gridColumn10.Visible = true;
            this.gridColumn10.VisibleIndex = 0;
            // 
            // gridColumn11
            // 
            this.gridColumn11.Caption = "Tên Khách Hàng";
            this.gridColumn11.FieldName = "TenKhachHang";
            this.gridColumn11.Name = "gridColumn11";
            this.gridColumn11.Visible = true;
            this.gridColumn11.VisibleIndex = 1;
            // 
            // gridColumn12
            // 
            this.gridColumn12.Caption = "Điện Thoại";
            this.gridColumn12.FieldName = "DienThoai";
            this.gridColumn12.Name = "gridColumn12";
            this.gridColumn12.Visible = true;
            this.gridColumn12.VisibleIndex = 2;
            // 
            // gridColumn13
            // 
            this.gridColumn13.Caption = "CMND";
            this.gridColumn13.FieldName = "CMND";
            this.gridColumn13.Name = "gridColumn13";
            this.gridColumn13.Visible = true;
            this.gridColumn13.VisibleIndex = 3;
            // 
            // gridColumn14
            // 
            this.gridColumn14.Caption = "Điểm Tích Lũy";
            this.gridColumn14.FieldName = "DiemTichLuy";
            this.gridColumn14.Name = "gridColumn14";
            this.gridColumn14.Visible = true;
            this.gridColumn14.VisibleIndex = 4;
            // 
            // repositoryItemSpinEdit1
            // 
            this.repositoryItemSpinEdit1.AutoHeight = false;
            this.repositoryItemSpinEdit1.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.repositoryItemSpinEdit1.Name = "repositoryItemSpinEdit1";
            // 
            // frmBanHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1307, 679);
            this.Controls.Add(this.panelControl1);
            this.Controls.Add(this.barDockControlLeft);
            this.Controls.Add(this.barDockControlRight);
            this.Controls.Add(this.barDockControlBottom);
            this.Controls.Add(this.barDockControlTop);
            this.FormBorderEffect = DevExpress.XtraEditors.FormBorderEffect.Shadow;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MaximizeBox = false;
            this.Name = "frmBanHang";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "HỆ THỐNG QUẢN LÝ NHÀ HÀNG - CAFE";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmBanHang_FormClosing);
            this.Load += new System.EventHandler(this.frmBanHang_Load);
            ((System.ComponentModel.ISupportInitialize)(this.panelControl1)).EndInit();
            this.panelControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl4)).EndInit();
            this.groupControl4.ResumeLayout(false);
            this.groupControl4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.lableTongTien)).EndInit();
            this.lableTongTien.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.cmbTenKhachHang.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.barManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridLookUpEdit1View)).EndInit();
            this.tableLayoutPanel1.ResumeLayout(false);
            this.tableLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtTienThoi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachThanhToan.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtKhachCanTra.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtGiamGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtDiemTichLuy.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTongTien.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.panelControl2)).EndInit();
            this.panelControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridControlCTHD)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.menuBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.repositoryItemSpinEdit1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.PanelControl panelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.PanelControl panelControl2;
        private DevExpress.XtraEditors.PanelControl lableTongTien;
        private DevExpress.XtraEditors.PanelControl panelControl3;
        private DevExpress.XtraEditors.GroupControl groupControl4;
        private DevExpress.XtraEditors.SimpleButton btnTrong;
        private DevExpress.XtraEditors.SimpleButton btnCoNguoi;
        private DevExpress.XtraEditors.SimpleButton btnDatTruoc;
        private DevExpress.XtraEditors.LabelControl txtTyLyPhucVu;
        private System.Windows.Forms.FlowLayoutPanel tblTable1;
        private DevExpress.XtraBars.PopupMenu menuBan;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem barButtonXoaBan;
        private DevExpress.XtraBars.BarButtonItem barButtonChuyenBan;
        private DevExpress.XtraBars.BarButtonItem barButtonGopBan;
        private DevExpress.XtraBars.BarManager barManager1;
        private DevExpress.XtraBars.BarDockControl barDockControlTop;
        private DevExpress.XtraBars.BarDockControl barDockControlBottom;
        private DevExpress.XtraBars.BarDockControl barDockControlLeft;
        private DevExpress.XtraBars.BarDockControl barDockControlRight;
        private DevExpress.XtraBars.BarButtonItem barButtonItem5;
        private DevExpress.XtraBars.BarButtonItem barButtonDatBan;
        private DevExpress.XtraBars.BarButtonItem barButtonChonMon;
        private DevExpress.XtraBars.BarButtonItem barButtonTachBan;
        private DevExpress.XtraGrid.GridControl gridControlCTHD;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn1;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn2;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn3;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn4;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn5;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn6;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn7;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn8;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn9;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.SimpleButton btnKetCa;
        private DevExpress.XtraEditors.SimpleButton btnInHoaDon;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.LabelControl txtTenDangNhap;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.SpinEdit txtTongTien;
        private DevExpress.XtraEditors.SpinEdit txtTienThoi;
        private DevExpress.XtraEditors.SpinEdit txtKhachThanhToan;
        private DevExpress.XtraEditors.SpinEdit txtKhachCanTra;
        private DevExpress.XtraEditors.SpinEdit txtGiamGia;
        private DevExpress.XtraEditors.SpinEdit txtDiemTichLuy;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl txtCMND;
        private DevExpress.XtraEditors.LabelControl txtDienThoai;
        private DevExpress.XtraEditors.LabelControl txtMaKhachHang;
        private DevExpress.XtraEditors.LabelControl txtDiem;
        private DevExpress.XtraEditors.LabelControl lblTime;
        private System.Windows.Forms.Timer timer1;
        private DevExpress.XtraEditors.LabelControl txtGioVao;
        private DevExpress.XtraEditors.SimpleButton btnThemKhachHang;
        private DevExpress.XtraEditors.GridLookUpEdit cmbTenKhachHang;
        private DevExpress.XtraGrid.Views.Grid.GridView gridLookUpEdit1View;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn10;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn11;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn12;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn13;
        private DevExpress.XtraGrid.Columns.GridColumn gridColumn14;
        private DevExpress.XtraEditors.Repository.RepositoryItemSpinEdit repositoryItemSpinEdit1;

    }
}